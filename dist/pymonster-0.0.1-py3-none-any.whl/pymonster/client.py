import argparse
import asyncio
import ssl
import websockets
from . import utils
from websockets.exceptions import ConnectionClosed, ConnectionClosedError
from .utils import print_and_flush, handle_shutdown
from .controller import control_cmd
from .beast import Beast
from .logger import log_server

# accept self-signed certificate
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

################################################################################
# No need to change functionality below this line
# You should remove most of the debug print statements to save disk space.
################################################################################


async def client_loop(
    username: str, password_file_name: str, hostname: str, port: int
):
    """
    Asynchronously connects to a websocket server and performs a client loop.

    Args:
        username (str): The username for authentication.
        password_file_name (str): Name of file containing password
            for authentication.
        hostname (str): The hostname of the websocket server.
        port (int): The port number of the websocket server.

    Returns:
        None
    """
    try:
        with open(password_file_name, "r", encoding="utf-8") as password_file:
            password = password_file.read().rstrip("\n")
            password = password.strip()
            log_server("SUCCESS", "Read password_file successfully")
    except (FileNotFoundError, PermissionError, IsADirectoryError) as e:
        log_server("ERROR", "Error reading Password file")
        raise type(e)("Error reading Password file") from e

    async with websockets.connect(
        f"wss://{hostname}:{port}/login",
        ssl=ssl_context,
    ) as websocket:
        await websocket.send(f"{username}:{password}")
        server_str = await websocket.recv()
        log_server("SMSG", f"{server_str!r}")
        print_and_flush(f"Reply from server: {server_str!r}")
        # the server creates one beast with random position and the
        # start energy
        # Biest hier intitalisieren!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        my_beast = Beast()
        utils.GLOBAL_BEAST_LIST.append(my_beast)
        while True:
            try:
                server_str = await websocket.recv()
                # log_server("SMSG", f"{server_str!r}")
                # remove this output eventually ...
                # print_and_flush(f"{server_str = }")
                # since control_cmd() is async, we need to await the return boolean and stop if it returns false (server shutdown)
                keep_running = await control_cmd(
                    server_str, websocket, my_beast
                )
                if not keep_running:
                    break
            except websockets.ConnectionClosedError:
                print_and_flush("Connection closed by server")
                log_server("ERROR", "Connection closed by server")
                break
        await handle_shutdown()


def client_main():
    """
    Parse the command line and start the client loop with the appropriate
    arguments.

    Args:
        None.

    Returns:
        None.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("username", help="User name for authentification")
    parser.add_argument(
        "password_file_name",
        help="Name of File containing Password for authentification.",
    )
    parser.add_argument(
        "-n", "--hostname", type=str, help="Host name", default="localhost"
    )
    parser.add_argument(
        "-p", "--port", type=int, help="Port number", default=9721
    )
    args = parser.parse_args()
    try:
        asyncio.run(
            client_loop(
                args.username,
                args.password_file_name,
                args.hostname,
                args.port,
            )
        )
    except ConnectionClosed:
        print_and_flush("Connection closed by server")
        log_server("ERROR", "Connection closed by server")


if __name__ == "__main__":
    client_main()
