"""TODO: Enter docstring for module logic.py"""

import math
import random
from . import utils
import numpy as np
from .utils import print_and_flush, cmd, handle_shutdown
from .logger import log_beast

HIGH_ENERGY_THRESHOLD = 100  # für high_energy boolean in flee_advanced()
FIELD_WIDTH = 71
FIELD_HEIGHT = 34

MIN_ABS_X = -(FIELD_WIDTH // 2)  # -35
MAX_ABS_X = MIN_ABS_X + FIELD_WIDTH - 1  # 35  -> [-35..35]

MIN_ABS_Y = -(FIELD_HEIGHT // 2)  # -17
MAX_ABS_Y = MIN_ABS_Y + FIELD_HEIGHT - 1  # 16  -> [-17..16]


def filter_valid_moves(arr, limit=3):
    """
    Entfernt alle Tupel aus einem NumPy-Array,
    deren Werte außerhalb des erlaubten Bereichs [-limit, limit] liegen.
    """
    if arr.size == 0:
        # Gibt das leere Array sofort zurück, wenn es leer ist.
        # print(arr)
        return np.zeros((0, 2), dtype=int)
    else:
        mask = np.all(
            np.abs(arr) < limit, axis=1
        )  # Die Maske filtert nach allen Betragstupeln die kleiner als N = 3 sind
        return arr[mask]


def array_to_dict(arr, priority):
    """"""
    move_dict = {}

    current_priority = priority

    for move in arr:
        move_tuple = tuple(move)

        move_dict[move_tuple] = current_priority

        current_priority -= 1

    return move_dict


def merge_dict(*dicts):
    merge_dict = {}

    for d in dicts:
        for move, priority in d.items():
            # print(f"{move=} / {priority=}")
            if move in merge_dict:
                merge_dict[move] += priority
            else:
                merge_dict[move] = priority

    # print(f"{merge_dict=}")
    return merge_dict


def calc_move_energy(move_tuple):
    x = move_tuple[0]
    y = move_tuple[1]

    # berechnet die Hypothenuse für die energy
    energy = math.hypot(x, y)

    return energy


def wrap_centered(value: int, min_v: int, max_v: int) -> int:
    """
    Wrappt einen Wert in das Intervall [min_v, max_v] (toroidal, modulo).
    Funktioniert auch für negative Werte.
    """
    span = max_v - min_v + 1
    return ((value - min_v) % span) + min_v


def wrap_abs_coords(x: int, y: int) -> tuple[int, int]:
    """
    Wendet zentriertes Wrapping auf die absoluten Koordinaten an.
    0,0 liegt hierbei im Zentrum des Spielfelds.
    """
    wrapped_x = wrap_centered(x, MIN_ABS_X, MAX_ABS_X)
    wrapped_y = wrap_centered(y, MIN_ABS_Y, MAX_ABS_Y)
    return wrapped_x, wrapped_y


def check_beast_collision(move, abs_x, abs_y):
    dx = move[0]
    dy = move[1]
    new_abs_x = abs_x + dx
    new_abs_y = abs_y + dy

    # Check Wrap
    new_abs_x, new_abs_y = wrap_abs_coords(new_abs_x, new_abs_y)

    for beast in utils.GLOBAL_BEAST_LIST:
        ally_abs_x = beast.get_abs_x()
        ally_abs_y = beast.get_abs_y()
        if ally_abs_x == new_abs_x and ally_abs_y == new_abs_y:
            return False

    return True


def valid_first_move(sorted_moves, current_energy, abs_x, abs_y):
    for (dx, dy), prio in sorted_moves:
        move = (int(dx), int(dy))
        no_collision = check_beast_collision(move, abs_x, abs_y)
        if not no_collision:
            continue

        if move == (0, 0):
            continue

        move_energy = calc_move_energy(move)
        if move_energy <= current_energy:
            return move, move_energy, prio
        else:
            continue
    return (0, 0), 0.0, 0  # "Der Energieverbauch für diesen Move ist zu Hoch"


def decide_action(curr_beast):
    abs_r = curr_beast.get_round_abs()
    if abs_r > 100:
        curr_beast.set_priority_energy(1.9)
    # call Modules an save lists
    bid = curr_beast.get_id()
    abs_x = curr_beast.get_abs_x()
    abs_y = curr_beast.get_abs_y()

    curr_beast.chase_food()
    curr_beast.hunt()
    curr_beast.compute_kill_list()
    curr_beast.escape()
    split_pos, do_split = curr_beast.split()
    if do_split:
        chosen_cmd = "SPLIT"

        d_x = split_pos[0]
        d_y = split_pos[1]

        new_abs_x, new_abs_y = wrap_abs_coords(abs_x + d_x, abs_y + d_y)

        move = (d_x, d_y)
        server_command = f"{bid} {cmd.SPLIT} {d_x} {d_y}"

    else:
        chosen_cmd = "MOVE"
        food_list = curr_beast.get_food_list()
        hunt_list = curr_beast.get_hunt_list()
        kill_list = curr_beast.get_kill_list()
        escape_list = curr_beast.get_escape_list()

        food_arr_temp = np.array(food_list)
        hunt_arr_temp = np.array(hunt_list)
        kill_arr_temp = np.array(kill_list)
        escape_arr_temp = np.array(escape_list)

        food_arr = filter_valid_moves(food_arr_temp)
        hunt_arr = filter_valid_moves(hunt_arr_temp)
        kill_arr = filter_valid_moves(kill_arr_temp)
        escape_arr = filter_valid_moves(escape_arr_temp)

        food_dict = array_to_dict(food_arr, curr_beast.get_priority_food())
        hunt_dict = array_to_dict(hunt_arr, curr_beast.get_priority_hunt())
        kill_dict = array_to_dict(kill_arr, curr_beast.get_priority_kill())
        escape_dict = array_to_dict(
            escape_arr, curr_beast.get_priority_escape()
        )

        merged_dict = merge_dict(food_dict, hunt_dict, kill_dict, escape_dict)

        clean_dict = {
            tuple(int(k_val) for k_val in move): int(priority)
            for move, priority in merged_dict.items()
        }

        sorted_dict = sorted(
            clean_dict.items(), key=lambda item: item[1], reverse=True
        )

        current_energy = curr_beast.get_energy()

        move, energy, priority = valid_first_move(
            sorted_dict, current_energy, abs_x, abs_y
        )  # Noch implementieren das der nächste move der Liste genommen werden soll

        # print(f"\nBest Move: {move} mit Priorität {priority} kosten Energy {energy}")
        d_x = move[0]
        d_y = move[1]

        new_abs_x, new_abs_y = wrap_abs_coords(abs_x + d_x, abs_y + d_y)

        curr_beast.set_abs_x(new_abs_x)
        curr_beast.set_abs_y(new_abs_y)
        server_command = f"{bid} {cmd.MOVE} {d_x} {d_y}"

    # Runden Erhöhen um 1
    curr_beast.set_round_abs(1)
    curr_beast.set_round_rel(1)

    # Log Aufruf
    abs_r = curr_beast.get_round_abs()
    rel_r = curr_beast.get_round_rel()
    energy = curr_beast.get_energy()
    environment = curr_beast.get_environment()
    # move
    # position
    abs_x = curr_beast.get_abs_x()
    abs_y = curr_beast.get_abs_y()
    # listen und prios
    food_list = curr_beast.get_food_list()
    priority_food = curr_beast.get_priority_food()
    hunt_list = curr_beast.get_hunt_list()
    priority_hunt = curr_beast.get_priority_hunt()
    kill_list = curr_beast.get_kill_list()
    priority_kill = curr_beast.get_priority_kill()
    escape_list = curr_beast.get_escape_list()
    priority_escape = curr_beast.get_priority_escape()
    priority_energy = curr_beast.get_priority_energy()

    log_beast(
        abs_r=abs_r,
        rel_r=rel_r,
        bid=bid,
        cmd=chosen_cmd,
        e=energy,
        env=environment,
        move=move,
        abs_x=abs_x,
        abs_y=abs_y,
        fl=food_list,
        pf=priority_food,
        hl=hunt_list,
        ph=priority_hunt,
        kl=kill_list,
        pk=priority_kill,
        el=escape_list,
        pe=priority_escape,
        pen=priority_energy,
    )

    return server_command, (new_abs_x, new_abs_y), abs_r


# beast = Beast()
# beast.set_id(1)
# beast.set_energy(40)
# beast.set_environment(".<.........*....>...**.....<..<......=...*....*..")
# # Testaufruf
# result = decide_action(beast)
# print(result)
# async def handle_beast_command_request(
#     websocket: WebSocketClientProtocol,
#     beast_id: int,
#     energy: float,
#     environment: str,
# ) -> int | None:
#     """
#     Handle a beast in the game.  This sample function performs a random
#     movement.

#     Args:
#         websocket: WebSocketClientProtocol: Connection to the server.
#         beast_id (int): The ID of the beast.
#         energy (float): The energy level of the beast.
#         environment (str): The environment as 1d string.

#     """
#     if energy > 100 and not ">" in environment:
#         d_x, d_y = random.choice(((0, 1), (0, -1), (-1, 0), (1, 0)))
#         server_command = f"{beast_id} {cmd.SPLIT} {d_x} {d_y}"
#     else:
#         if random.randint(0, 12345) % 5 == 0:
#             # completely random movement
#             d_x = random.randint(-2, 2)
#             d_y = random.randint(-2, 2)
#         else:
#             # move right
#             d_x, d_y = 1, 0
#         server_command = f"{beast_id} {cmd.MOVE} {d_x} {d_y}"
#     print_and_flush(f'sending "{server_command}"')
#     # don't change the next line or you will break the protocol
#     await websocket.send(server_command)
#     server_str = await websocket.recv()
#     if "ERROR" in server_str:
#         print_and_flush(server_str)
#         success_str = "False"
#         new_beast_id_str = "None"
#     else:
#         new_beast_id_str, success_str = server_str.split("#")
#     # successful split
#     if success_str == "True" and new_beast_id_str != "None":
#         new_beast_id = int(new_beast_id_str)
#         return new_beast_id

#     # hier kommt Beast Brain rein was vorher def decide_action() war
#     return None


async def handle_beast_gone(
    beast_id: int,
    energy: float,
    environment: str,
) -> None:
    """
    Handle the situation of a beast starving to death or being eaten
    by another beast.

    Args:
        beast_id (int): The ID of the beast.
        energy (float): The energy level of the beast.
        environment (str): The environment as 1d string.
    """
    # replace this ...
    for beast in utils.GLOBAL_BEAST_LIST:
        beast_id_list = beast.get_id()
        if beast_id == beast_id_list:
            utils.GLOBAL_BEAST_LIST.remove(beast)

    print_and_flush(f"beast {beast_id} with energy {energy} gone")
    print_and_flush(f"  environment: {environment}")


async def handle_no_beasts_left() -> None:
    """
    Handles the case when there are no beasts left.
    """
    # replace this ...
    print_and_flush("No beasts left")
    await handle_shutdown()
