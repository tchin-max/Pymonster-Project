"""TODO: Enter docstring for module common.py"""

from collections import namedtuple
import os
import signal
import sys

GLOBAL_BEAST_LIST = []


def print_and_flush(message: str):
    """
    Prints a given message to the console and flushes the
    output stream.

    Args:
        message (str): The message to be printed.

    Returns:
        None
    """
    print(message)
    sys.stdout.flush()


Command = namedtuple(
    "Command",
    [
        "BEAST_COMMAND_REQUEST",
        "BEAST_GONE_INFO",
        "NO_BEASTS_LEFT_INFO",
        "SHUTDOWN_INFO",
        "MOVE",
        "SPLIT",
    ],
)

cmd = Command(
    BEAST_COMMAND_REQUEST="BEAST_COMMAND_REQUEST",
    BEAST_GONE_INFO="BEAST_GONE_INFO",
    NO_BEASTS_LEFT_INFO="NO_BEASTS_LEFT_INFO",
    SHUTDOWN_INFO="SHUTDOWN_INFO",
    MOVE="MOVE",
    SPLIT="SPLIT",
)


async def handle_shutdown():  # Soll als eine Art Exception fungieren/arbeiten.
    """
    Handles the shutdown event.

    This function is responsible for gracefully handling the shutdown event.
    It prints "bye" to the console.
    """
    # replace this ...
    print_and_flush("bye")
    sys.stdout.flush()
    os.kill(os.getpid(), signal.SIGTERM)
