import random
import numpy as np
import math
from collections import OrderedDict
from . import utils
from .logic import wrap_abs_coords


class Beast:
    """
    The Beast Class is responsible for managing the state and behavior of a single
    beast within a 5x5 grid environment.
    The Beast has an ID, energy level, and position on the grid.
    It moves according his brain which contains a lot of if and else statements
    which determine the movement based on the defined conditions
    and perform actions based on the energy level.
    """

    def __init__(self):
        """
        spwan-point:
        x = 3  # 4.column
        y = 3  # 4.row
        """
        self._id = 0
        self._energy = 0.0
        self._environment = ""

        self._priority_food = 35
        self._priority_hunt = 10
        self._priority_kill = 40
        self._priority_escape = 90
        self._priority_energy = 3.0

        self.x = 3
        self.y = 3

        self._food_list = []
        self._escape_list = []
        self._hunt_list = []
        self._kill_list = []

        self._round_abs = 0
        self._round_rel = 0
        self._abs_x = 0
        self._abs_y = 0

    def get_id(self):
        return self._id

    def get_environment(self):
        return self._environment

    def get_energy(self):
        return self._energy

    def get_food_list(self):
        return self._food_list

    def get_escape_list(self):
        return self._escape_list

    def get_hunt_list(self):
        return self._hunt_list

    def get_priority_food(self):
        return self._priority_food

    def get_kill_list(self):
        return self._kill_list

    def get_priority_escape(self):
        return self._priority_escape

    def get_priority_hunt(self):
        return self._priority_hunt

    def get_priority_kill(self):
        return self._priority_kill

    def get_priority_energy(self):
        return self._priority_energy

    def get_round_abs(self):
        return self._round_abs

    def get_round_rel(self):
        return self._round_rel

    def get_abs_x(self):
        return self._abs_x

    def get_abs_y(self):
        return self._abs_y

    # Setter

    def set_id(self, updated_id):
        self._id = updated_id
        return

    def set_energy(self, updated_energy: float):
        self._energy = updated_energy
        return

    def set_environment(self, updated_environment):
        self._environment = updated_environment

    def set_priority_food(self, updated_priority_food):
        self._priority_food = updated_priority_food
        return

    def set_priority_escape(self, updated_priority_escape):
        self._priority_escape = updated_priority_escape
        return

    def set_priority_hunt(self, updated_priority_hunt):
        self._priority_hunt = updated_priority_hunt
        return

    def set_priority_kill(self, updated_priority_kill):
        self._priority_kill = updated_priority_kill
        return

    def set_priority_energy(self, updated_priority_energy: float):
        self._priority_energy = updated_priority_energy
        return

    def set_kill_list(self, updated_kill_list):
        self._kill_list = updated_kill_list

    def set_food_list(self, updated_food_list):
        self._food_list = updated_food_list

    def set_escape_list(self, updated_escape_list):
        self._escape_list = updated_escape_list

    def set_hunt_list(self, updated_hunt_list):
        self._hunt_list = updated_hunt_list

    def set_round_abs(self, round_increment):
        self._round_abs += round_increment

    def set_round_rel(self, round_increment):
        self._round_rel += round_increment

    def set_abs_x(self, updated_abs_x):
        self._abs_x = updated_abs_x

    def set_abs_y(self, updated_abs_y):
        self._abs_y = updated_abs_y

    def __str__(self) -> str:
        # Erweitern mit den Listen damit man die Zustände der Biester
        # immer durch Logging speichern können.
        return f"{self._id}#{self._energy}#{self._environment}"

    def parse_environment(self, env: str):
        """
        Here parseEnvironment should parse the single line 'env' string into
        a list of lists, where each sublist represents a row of the
        environment matrix.
        Or it should return something numerical, so we could utilze it
        better for our later analysis of 'next move prediction'.
        """
        # according to to the size of our game (2N+1)x(2N+1), we need a initializer N=3
        # and the actual size: size = 2*N+1

        N: int = 3
        size_game: int = 2 * N + 1

        result = [
            list(env[element : element + size_game])
            for element in range(0, len(env), size_game)
        ]
        result[N][N] = "B"  # Tell us where the Beast is

        numpy_env = np.array(result)
        return numpy_env

    def _is_safe_move(self, move: tuple[int, int]) -> bool:
        """
        Prüft, ob ein relativer Move (dx, dy) auf dem globalen Spielfeld
        zu einer Kollision mit einem unserer anderen Beasts führen würde.

        Der Move ist relativ zu unserer aktuellen Position (self._abs_x, self._abs_y).
        Spielfeld-Wrapping wird berücksichtigt.
        """
        dx, dy = move

        # berechnet die neunen Absolut Coords
        new_abs_x, new_abs_y = wrap_abs_coords(
            self._abs_x + dx, self._abs_y + dy
        )

        for beast in utils.GLOBAL_BEAST_LIST:
            # eigenes Beast überspringen eigentlich egal weil wir nie stehen bleiben
            if beast.get_id() == self._id:
                continue

            if (
                beast.get_abs_x() == new_abs_x
                and beast.get_abs_y() == new_abs_y
            ):
                return False  # hier steht eines von uns

        return True  # feld ist safe

    def random_move(self):
        """
        Gibt eine zufällige Bewegung in den vier Hauptachsen zurück.

        Returns:
            tuple[int, int]: Einer der Moves (1,0), (-1,0), (0,1), (0,-1).
        """
        d_x, d_y = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        return d_x, d_y

    def rest(self):
        """
        If the beast has less than 10 energy, the beast should rest
        pray for food.
        """
        return

    def _move_energy(self, move: tuple[int, int]) -> float:
        """
        Berechnet die Energie (Distanz) eines Moves (dx, dy).
        """
        dx, dy = move
        return math.hypot(dx, dy)

    def _is_move_within_energy_limit(self, move: tuple[int, int]) -> bool:
        """
        Prüft, ob ein Move innerhalb der durch _priority_energy
        gesetzten Energiebeschränkung liegt.
        """
        return self._move_energy(move) <= self._priority_energy

    def _clamp_move(
        self, dx: int, dy: int, max_step: int = 2
    ) -> tuple[int, int]:
        """
        Begrenzung eines Moves auf den erlaubten Bereich [-2, +2].

        Moves, die zu groß sind, werden auf gültige Werte gestutzt,
        bleiben aber in dieselbe Richtung orientiert.

        Args:
            dx (int): Delta-X des Moves.
            dy (int): Delta-Y des Moves.

        Returns:
            tuple[int, int]: Gekürzter, gültiger Move.
        """
        max_step = max(1, int(max_step))
        dx = max(-max_step, min(max_step, dx))
        dy = max(-max_step, min(max_step, dy))
        return dx, dy

    def _simulate_future_environment(self, first_move: tuple[int, int]):
        """
        Simuliert das 7x7-Sichtfeld nach Ausführung eines ersten Moves.

        Dabei wird das gesamte Environment so verschoben, als hätte das Beast
        sich bereits um (dx, dy) bewegt. Bereiche außerhalb werden mit '.'
        aufgefüllt, und das Beast wird wieder in die Mitte gesetzt.

        Args:
            first_move (tuple[int, int]): Der Move (dx, dy), der simuliert wird.

        Returns:
            numpy.ndarray: Das zukünftige 7x7-Sichtfeld.
        """
        dx, dy = first_move

        # ursprüngliches 7x7-Feld holen
        field = self.parse_environment(self._environment).copy()

        # 'B' im alten Feld entfernen, wir interessieren uns nur für Futter / Gegner
        field[field == "B"] = "."

        size = field.shape[0]  # 7
        new_field = np.full((size, size), ".", dtype=str)

        # Sichtfeld so verschieben, als ob das Beast um (dx, dy) gegangen wäre
        for new_y in range(size):
            for new_x in range(size):
                src_x = new_x + dx
                src_y = new_y + dy
                if 0 <= src_x < size and 0 <= src_y < size:
                    new_field[new_y][new_x] = field[src_y][src_x]

        # Beast sitzt in der Zukunft wieder in der Mitte
        center = size // 2
        new_field[center][center] = "B"
        return new_field

    def _food_moves_in_field(self, field) -> list[tuple[int, int]]:
        """
        Bestimmt alle möglichen Food-Moves im gegebenen 7x7-Feld,
        geclampt auf max_step (1 oder 2, abhängig von _priority_energy).

        Jeder Fund eines Futterzeichens ('*') wird relativ zur Feldmitte in
        einen Move umgerechnet und anschließend über _clamp_move begrenzt.

        Args:
            field (numpy.ndarray): Ein 7x7-Feld.

        Returns:
            list[tuple[int, int]]: Liste der Moves (dx, dy) zum Futter.
        """
        size = field.shape[0]
        center = size // 2
        moves: list[tuple[int, int]] = []
        seen: set[tuple[int, int]] = set()

        max_step = 1 if self._priority_energy < 2.0 else 2

        for y in range(size):
            for x in range(size):
                if field[y][x] == "*":
                    diff_x = x - center
                    diff_y = y - center
                    dx, dy = self._clamp_move(diff_x, diff_y, max_step)
                    move = (dx, dy)
                    if move not in seen:
                        seen.add(move)
                        moves.append(move)
        return moves

    def _score_two_step_food(
        self,
        m1: tuple[int, int],
        future_moves: list[tuple[int, int]],
        is_direct_hit: bool,  # NEU: Flag zur Unterscheidung
    ) -> float:
        """
        Bewertet einen Start-Move m1 anhand eines Zwei-Schritt-Lookaheads.
        (Angepasst zur Vermeidung des Double-Countings bei clamped Moves)
        """
        BONUS_PER_FOOD = 10.0

        dist1 = math.hypot(*m1)

        if future_moves:
            # bester zweiter Schritt (kürzeste Distanz)
            dist2 = min(math.hypot(dx, dy) for dx, dy in future_moves)
            extra_foods = len(future_moves)
        else:
            dist2 = 0.0
            extra_foods = 0

        # Nur Basis-Food-Bonus (10.0) addieren, wenn der Move direkt auf das Food führt (is_direct_hit = True)
        base_food_bonus = 1 if is_direct_hit else 0

        total_foods = base_food_bonus + extra_foods
        score = total_foods * BONUS_PER_FOOD - (dist1 + dist2)
        return score

    def _score_food_moves_with_lookahead(
        self,
        moves: list[tuple[int, int]],
        is_direct_hit_path: bool,  # NEU: Parameter hinzugefügt
    ) -> list[tuple[int, int]]:
        """
        Bewertet bis zu sechs Food-Moves mit Zukunftssimulation.
        (Angepasst zur Übergabe des is_direct_hit_path Flags)
        """
        scores: dict[tuple[int, int], float] = {}
        MAX_LOOKAHEAD = 6

        for idx, m1 in enumerate(moves):
            dist1 = math.hypot(*m1)

            # Basis-Score, wenn wir keinen Lookahead machen.
            # Der Basis-Score ist hier nicht entscheidend, da er nur für idx >= 6 benutzt wird.
            base_score = (10.0 if is_direct_hit_path else 0.0) - dist1

            if idx < MAX_LOOKAHEAD:
                # Zukunftsfeld simulieren & erneut Futter-Suche
                future_field = self._simulate_future_environment(m1)
                future_moves = self._food_moves_in_field(future_field)
                # Übergabe des Flags an die Scoring-Funktion
                score = self._score_two_step_food(
                    m1, future_moves, is_direct_hit_path
                )
            else:
                # nur Ein-Schritt-Bewertung (fällt selten an)
                score = base_score

            scores[m1] = score

        # Moves nach Score absteigend sortieren
        sorted_moves = sorted(moves, key=lambda mv: scores[mv], reverse=True)

        return sorted_moves

    def chase_food(self) -> list[tuple[int, int]]:
        """
        Futter-Suche mit Zwei-Schritt-Lookahead.
        (Angepasst zur Trennung von in_range und clamped Pfaden)

        Im Normalmodus (2er-Moves erlaubt):
        -> 1-er oder 2-er Moves, je nach Abstand

        Im 1er-Move-Modus:
        -> _chase_food_one_step().
        """

        # 0) Rohdaten (relative Positionen)
        raw = self.locate_food_list()

        # 0a) Kein Food im Sichtfeld -> Random-Fallback
        if not raw:
            rx, ry = self.random_move()
            moves = [(rx, ry)]
            self.set_food_list(moves)
            return moves

        # 0b) 1er-Move-Modus? -> 1er-Move-Funktion benutzen
        if self._priority_energy < 2.0:
            return self._chase_food_one_step(raw)

        # 1) Nur Moves betrachten, die im erlaubten 5x5 liegen (|dx|,|dy| <= 2)
        in_range = [
            (dx, dy) for (dx, dy) in raw if -2 <= dx <= 2 and -2 <= dy <= 2
        ]

        if in_range:
            # IN_RANGE PFAD: Direkter Hit möglich (is_direct_hit_path = True)

            # nach Distanz (und leichtem Tie-Break) sortieren und duplizierte Moves entfernen
            uniq: list[tuple[int, int]] = []
            seen: set[tuple[int, int]] = set()
            for mv in sorted(
                in_range, key=lambda m: (math.hypot(*m), abs(m[0]) + abs(m[1]))
            ):
                if mv not in seen:
                    seen.add(mv)
                    uniq.append(mv)

            # Aufruf mit is_direct_hit_path = True
            best = (
                self._score_food_moves_with_lookahead(uniq, True)
                if len(uniq) <= 7
                else uniq
            )

            best = [mv for mv in best if self._is_move_within_energy_limit(mv)]

            if not best:
                rx, ry = self.random_move()
                moves = [(rx, ry)]
                self.set_food_list(moves)
                return moves

            self.set_food_list(best)
            return best

        # 2) Kein erreichbares Food -> clamped Richtungen bilden
        clamped: list[tuple[int, int]] = []
        seen: set[tuple[int, int]] = set()
        for dx, dy in raw:
            mv = self._clamp_move(dx, dy)
            if mv not in seen:
                seen.add(mv)
                clamped.append(mv)

        clamped.sort(key=lambda m: (math.hypot(*m), abs(m[0]) + abs(m[1])))

        # CLAMPED PFAD: Direkter Hit nicht möglich (is_direct_hit_path = False)
        # Aufruf mit is_direct_hit_path = False
        best = (
            self._score_food_moves_with_lookahead(clamped, False)
            if len(clamped) <= 7
            else clamped
        )

        best = [mv for mv in best if self._is_move_within_energy_limit(mv)]

        if not best:
            rx, ry = self.random_move()
            moves = [(rx, ry)]
            self.set_food_list(moves)
            return moves

        self.set_food_list(best)
        return best

    def locate_food_list(self) -> list:
        """
        Liefert sämtliche Lebensmittel-Positionen relativ zum Beast.

        Das Environment wird als 7x7-Feld interpretiert und alle Positionen
        mit '*' werden in relative Koordinaten (dx, dy) umgerechnet.

        Returns:
            list[tuple[int, int]]: Liste aller relativen Futterpositionen.
        """
        field = self.parse_environment(self._environment)
        food_list = []

        cx, cy = 3, 3  # Beast in der Mitte

        for y in range(7):
            for x in range(7):
                if field[y][x] == "*":
                    dx = x - cx
                    dy = y - cy
                    food_list.append((dx, dy))

        return food_list

    def _chase_food_one_step(
        self, raw: list[tuple[int, int]]
    ) -> list[tuple[int, int]]:
        """
        Futter-Suche im 1er-Move-Modus.

        Strategie:
        1. Food in den 8 direkten Nachbarzellen? -> direkt hinlaufen.
        2. Sonst: Food im 5x5-Bereich? -> Moves auf 1er-Moves clampen.
        3. Sonst: Food im restlichen 7x7? -> ebenfalls auf 1er-Moves clampen.
        4. Wenn gar kein Futter in Sichtweite ist -> random_move().
        """
        # Ring-Einteilung anhand der Chebyshev-Distanz
        neighbours: list[tuple[int, int]] = []
        ring5: list[tuple[int, int]] = []
        ring7: list[tuple[int, int]] = []

        for dx, dy in raw:
            cheby = max(abs(dx), abs(dy))
            if cheby == 1:
                neighbours.append((dx, dy))
            elif cheby <= 2:
                ring5.append((dx, dy))
            else:
                ring7.append((dx, dy))

        def unique_sorted(
            moves: list[tuple[int, int]],
        ) -> list[tuple[int, int]]:
            """Entfernt Duplikate und sortiert nach Distanz + kleinem Tie-Break."""
            uniq: list[tuple[int, int]] = []
            seen: set[tuple[int, int]] = set()
            for mv in sorted(
                moves, key=lambda m: (math.hypot(*m), abs(m[0]) + abs(m[1]))
            ):
                if mv not in seen:
                    seen.add(mv)
                    uniq.append(mv)
            return uniq

        candidate_moves: list[tuple[int, int]] = []
        is_direct_hit_path = False

        if neighbours:
            # 1) Direkte Nachbarn: tatsächlich erreichbares Futter
            candidate_moves = unique_sorted(neighbours)
            is_direct_hit_path = (
                True  # direkter Hit -> extra Food-Bonus im Scoring
            )
        elif ring5:
            # 2) Food im 5x5, aber nicht direkt an uns dran -> clampen auf 1er-Moves
            clamped: list[tuple[int, int]] = []
            seen: set[tuple[int, int]] = set()
            for dx, dy in ring5:
                mv = self._clamp_move(dx, dy, max_step=1)  # Annäherung
                if mv != (0, 0) and mv not in seen:
                    seen.add(mv)
                    clamped.append(mv)
            candidate_moves = unique_sorted(clamped)
            # is_direct_hit_path bleibt False -> keine Base-Food-Belohnung
        elif ring7:
            # 3) Food im äußeren Ring des 7x7 -> ebenfalls clampen
            clamped = []
            seen = set()
            for dx, dy in ring7:
                mv = self._clamp_move(dx, dy, max_step=1)
                if mv != (0, 0) and mv not in seen:
                    seen.add(mv)
                    clamped.append(mv)
            candidate_moves = unique_sorted(clamped)

        # Kein sinnvoller Kandidat -> wie bei "kein Food": Random-Fallback
        if not candidate_moves:
            rx, ry = self.random_move()
            moves = [(rx, ry)]
            self.set_food_list(moves)
            return moves

        # Lookahead + Scoring wie bisher, nur mit ggf. anderem is_direct_hit_path
        best = (
            self._score_food_moves_with_lookahead(
                candidate_moves, is_direct_hit_path
            )
            if len(candidate_moves) <= 7
            else candidate_moves
        )

        # Sicherheitshalber trotzdem Energie-Filter
        best = [mv for mv in best if self._is_move_within_energy_limit(mv)]

        if not best:
            rx, ry = self.random_move()
            moves = [(rx, ry)]
            self.set_food_list(moves)
            return moves

        self.set_food_list(best)
        return best

    #########################################

    def hunt(self) -> list:
        """
        Ermittelt alle Jagd-Moves auf Gegner ('<') innerhalb des 7x7-Felds.

        Schritte:
          - Gegnerpositionen suchen
          - relative Moves berechnen
          - Moves clampen
          - nach Distanz sortieren
          - Duplikate entfernen

        Returns:
            list[tuple[int, int]]: Sortierte Jagd-Moves (dx, dy).
        """
        unsorted_hunting_list = self.locate_hunting_list()

        x_beast, y_beast = 3, 3
        enemy_data = []

        max_step = 1 if self._priority_energy < 2.0 else 2

        for x_e, y_e in unsorted_hunting_list:
            diff_x = x_e - x_beast
            diff_y = y_e - y_beast

            c_diff_x, c_diff_y = self._clamp_move(diff_x, diff_y, max_step)
            total_distance = math.hypot(diff_x, diff_y)
            move_key = (c_diff_x, c_diff_y)

            enemy_data.append((total_distance, move_key))

        enemy_data.sort(key=lambda item: item[0])

        sorted_hunt_list = []
        seen_moves = set()
        for total_dist, move in enemy_data:
            if move not in seen_moves:
                seen_moves.add(move)
                sorted_hunt_list.append(move)

        if not sorted_hunt_list:
            self.set_hunt_list([])
            return []

        # Prüft ob der nächste move auf ein anderes unsere Biester steppt
        # wenn die liste true zurückliefert wird es in die liste gefügt
        safe_hunt_list = [
            move
            for move in sorted_hunt_list
            if self._is_safe_move(move)
            and self._is_move_within_energy_limit(move)
        ]

        self.set_hunt_list(safe_hunt_list)
        return safe_hunt_list

    def locate_hunting_list(self) -> list:
        """
        Sucht Gegner ('<') im Environment und gibt deren Positionen zurück.

        Returns:
            list[tuple[int, int]]: Absolute Gegnerkoordinaten im 7x7-Feld.
        """
        field = self.parse_environment(self._environment)
        hunting_list = list()
        opponent_symbols = {"<"}

        for r_idx, row in enumerate(field):
            for c_idx, col in enumerate(row):
                if col in opponent_symbols:
                    coordinate = (c_idx, r_idx)
                    hunting_list.append(coordinate)
        return hunting_list

    def locate_unique_enemy_moves(self) -> list:
        field = self.parse_environment(self._environment)
        enemy_list = []

        opponent_symbols = {">", "="}
        for r_idx, row in enumerate(field):
            for c_idx, col in enumerate(row):
                if col in opponent_symbols:
                    coordinate = (c_idx, r_idx)
                    enemy_list.append(self.locate_enemy_list(coordinate))

        unique_set = set()
        for enemy in enemy_list:
            unique_set.update(enemy)
        return list(unique_set)

    def get_enemy_positions(self) -> list:
        field = self.parse_environment(self._environment)

        enemy_list = []
        opponent_symbols = {">", "="}

        for r_idx, row in enumerate(field):
            for c_idx, col in enumerate(row):
                if col in opponent_symbols:
                    relative_x = c_idx - 3
                    relative_y = r_idx - 3

                    abs_x, abs_y = wrap_abs_coords(
                        self._abs_x + relative_x, self._abs_y + relative_y
                    )

                    # prüft das die neue Abs coordiante nicht keins unserer bieaster ist.
                    is_ally = False
                    for beast in utils.GLOBAL_BEAST_LIST:
                        # eigenes Beast überspringen ist nur zur Sicherheit
                        if beast.get_id() == self._id:
                            continue

                        if (
                            beast.get_abs_x() == abs_x
                            and beast.get_abs_y() == abs_y
                        ):
                            is_ally = True
                            break

                    # nur echte Gegner hinzufügen
                    if not is_ally:
                        enemy_list.append((relative_x, relative_y))

        return enemy_list

    def score_safe_moves(
        self, safe_moves: list, enemy_list: list
    ) -> tuple[list, dict]:
        score_by_move = {}

        for mx, my in safe_moves:
            score = 0.0
            for ex, ey in enemy_list:
                dx = mx - ex
                dy = my - ey
                score += math.hypot(dx, dy)
            score_by_move[(mx, my)] = score

        sorted_scores = OrderedDict(
            sorted(
                score_by_move.items(), key=lambda item: item[1], reverse=True
            )
        )
        sorted_moves = list(sorted_scores.keys())
        return sorted_moves, sorted_scores

    def compute_kill_list(self) -> list:
        """
        Scannt das 5x5-Sichtfeld (Koordinaten -2,-2 bis +2,+2 relativ zur
        eigenen Position) und liefert eine Liste möglicher Kill-Moves.

        Rückgabe:
          Liste von (dx, dy)-listen, die einen kleineren Gegner ('<')
           in Reichweite sicher erreichen können.
          Bei keinen Zielen -> leere Liste.
        """

        enemy_list = self.locate_hunting_list()
        kill_moves = []
        for x_e, y_e in enemy_list:
            # Beast sitzt in der Mitte (Index 3,3)
            dx = x_e - 3
            dy = y_e - 3

            # Nur Gegner im 5x5 Bereich zulassen
            if -2 <= dx <= 2 and -2 <= dy <= 2:
                kill_moves.append((dx, dy))

        # Sortieren nach Distanz (nächste Ziele zuerst)
        kill_moves.sort(key=lambda move: math.hypot(move[0], move[1]))

        # Prüft ob der nächste move auf ein anderes unsere Biester steppt
        # wenn die liste true zurückliefert wird es in die liste gefügt
        safe_kill_moves = [
            move for move in kill_moves if self._is_safe_move(move)
        ]

        self.set_kill_list(safe_kill_moves)
        return safe_kill_moves

    def split(self):
        """
        Entscheidet, ob sich dieses Beast in zwei neue Beasts aufteilt,
        und liefert im Erfolgsfall den Start-Move für das neue Beast aus
        unserer food_list() zurück.

        Die Funktion berechnet zunächst die durchschnittliche Energie pro Runde.
        Ein Split wird nur durchgeführt, wenn alle Bedingungen aus
        dem IF Statement erfüllt sind.

        Für den Fall, dass im späteren Verlauf des Spiels nur noch ein Beast übrig sein sollte, gibt es einen Notfall-Split, der genau dann greift, wenn die folgenden Bedingungen erfüllt sind:
            - es lebt nur noch ein eigenes Beast
            - mindestens 50 Energie
            - mindestens absolute Runde 100
            - keine Gegner im gesamten 5x5-Bereich (auch keine '<')
            - mindestens ein Futter im Sichtfeld

        Sind alle Bedingungen erfüllt, soll neuer Beast in einer der vier Ecken
        des 5 x 5 Sichtfeld des Beasts mit move platziert werden.

        Andernseits wird None und False zurückgegeben, wenn mindestens eine
        Bedingung nicht erfüllt.
        """

        # GENERAL_ENERGY_AVG wurde nach näherer Analysen der Futter-Runde
        # Verhältnis aus der beast logs vom 14.11.25 ermittelt und gezeigt
        # dass sich dieser Wert oder größer etwa eine Wahrscheinlichkeit von
        # 20% hat um vorzukommen.
        GENERAL_ENERGY_AVG: float = 2.5
        MINIMUM_SPLIT_ENERGY: float = 80.0

        # Drehschrauben für den Notfall-Split
        EMERGENCY_MIN_ENERGY: float = 50.0
        EMERGENCY_MIN_ROUND: float = 100

        # Schutz Div durch 0
        if self._round_abs <= 0:
            cur_energy_avg = 0.0
        else:
            cur_energy_avg: float = self._energy / self._round_abs

        food_list: list = self._food_list
        hunt_list: list = self._hunt_list
        escape_list: list = self._escape_list

        # ---------------------- Normaler Split ----------------------
        # Wir müssen hier die Anforderungen für den Split erfüllen
        if (
            self._energy > MINIMUM_SPLIT_ENERGY
            and cur_energy_avg >= GENERAL_ENERGY_AVG
            and len(hunt_list) == 0
            and len(escape_list) == 0
            and len(food_list) >= 4
        ):
            legal_moves = [(0, -1), (0, 1), (-1, 0), (1, 0)]

            move = None

            # 1. Suche: Ist einer der legalen Moves ein Food-Feld?
            for option in legal_moves:
                if option in food_list:
                    move = option
                    break  # Den ersten Treffer nehmen und Schleife beenden

            # 2. Fallback: Wenn kein Food da ist, nimm einen zufälligen legalen Move
            if move is None:
                move = random.choice(legal_moves)

            # Bedingungen == True -> Split erlaubt (True)
            # -> Bester Food-MOVE -> neuer beast spawnt auf dem Food.
            return move, True

        # ---------------------- Notfall-Split ----------------------
        # a) lebt nur noch 1 eigenes Beast?
        only_one_beast_left = len(utils.GLOBAL_BEAST_LIST) == 1

        # b) Mindestenergie + Mindest-Runde erreicht?
        has_min_energy_and_round = (
            self._energy >= EMERGENCY_MIN_ENERGY
            and self._round_abs >= EMERGENCY_MIN_ROUND
        )

        # c) Sichtfeld analysieren (direkt der String, weil z.B. Foodliste auch bei keinem Food im Sichtfeld NICHT leer ist, wegen random-Move)
        env_str = self._environment or ""

        # mindestens ein Futter im Sichtfeld?
        has_food_in_view = "*" in env_str

        # irgendein anderes Biest im 5x5-Bereich (Chebyshev <=2)?
        enemy_symbols = (">", "=", "<")
        field = self.parse_environment(env_str)

        size = field.shape[0]  # sollte 7 sein
        center = size // 2  # 3 -> unser Beast sitzt in der Mitte
        has_enemy_in_view = False

        for y in range(size):
            for x in range(size):
                if field[y][x] in enemy_symbols:
                    dx = x - center
                    dy = y - center
                    # Chebyshev-Distanz
                    if max(abs(dx), abs(dy)) <= 2:  # <=2 für 5x5-Bereich
                        has_enemy_in_view = True

        if (
            only_one_beast_left
            and has_min_energy_and_round
            and has_food_in_view
            and not has_enemy_in_view
        ):
            legal_moves = [(0, -1), (0, 1), (-1, 0), (1, 0)]
            move = None

            # 1. Suche: Wie beim normalen Split zuerst versuchen, direkt auf Food zu splitten
            for option in legal_moves:
                if option in food_list:
                    move = option
                    break  # Den ersten Treffer nehmen und Schleife beenden

            if move is None:
                # Fallback: zufälliger legaler Move, möglichst "sicher"
                move = random.choice(legal_moves)

            # Bedingungen == True -> Split erlaubt (True)
            # -> Bester Food-MOVE -> neuer beast spawnt auf dem Food.
            return move, True

        # ---------------------- Kein Split ----------------------
        # Bedingungen != True -> Kein MOVE (None) und Kein Split erlaubt (False)
        return None, False

    def locate_enemy_list(self, enemy: tuple) -> list:
        """ "
        returns the 5 x 5 environment of my_beast
        """
        my_list = list()
        for r_idx in range(-2, 2 + 1):  # r_idx ist y
            for c_idx in range(-2, 2 + 1):  # c_idx ist x
                coordinate = (c_idx + enemy[0], r_idx + enemy[1])
                if (
                    coordinate[0] <= 2
                    and coordinate[0] >= -2
                    and coordinate[1] <= 2
                    and coordinate[1] >= -2
                ):
                    my_list.append(coordinate)
        return my_list

    def escape(self) -> list:
        """
        Berechnet sichere Felder innerhalb unseres erlaubten 5x5-Bereiches (x,y ∈ [-2..2], (0,0) ausgeschlossen).
        """
        # 1) Alle Gegnerpositionen (relativ zu uns) holen
        enemy_list = self.get_enemy_positions()

        # Sofortregel: wenn kein Enemy vorhanden -> leere Liste zurückgeben
        if not enemy_list:
            self.set_escape_list([])
            return []

        # 2) Alle möglichen Moves im 5x5 (ohne (0,0))
        our_moves = [
            (x, y)
            for x in range(-2, 3)
            for y in range(-2, 3)
            if not (x == 0 and y == 0)
        ]

        # 3) Gefährliche Felder bestimmen (5x5 um jeden Gegner, geschnitten mit unserem 5x5)
        danger_moves_set = set()
        our_area_set = set((x, y) for x in range(-2, 3) for y in range(-2, 3))

        for ex, ey in enemy_list:
            for gx in range(ex - 2, ex + 3):
                for gy in range(ey - 2, ey + 3):
                    if (gx, gy) in our_area_set:
                        danger_moves_set.add((gx, gy))

        danger_moves_set.discard((0, 0))

        # 4) Sichere Moves = our_moves - danger_moves, zusätzlich globale Kollisionsprüfung
        safe_moves = [
            move for move in our_moves if move not in danger_moves_set
        ]
        safe_moves = [move for move in safe_moves if self._is_safe_move(move)]

        # WENN GAR KEIN sicherer Move -> raus
        if not safe_moves:
            self.set_escape_list([])
            return []

        # 5) Safe Moves nach Schrittweite in zwei Gruppen aufteilen
        one_step_moves = []
        longer_moves = []

        for mx, my in safe_moves:
            cheby = max(abs(mx), abs(my))  # Chebyshev-Distanz
            if cheby == 1:
                one_step_moves.append((mx, my))
            else:
                longer_moves.append((mx, my))

        result_moves: list[tuple[int, int]] = []

        # 6) ZUERST: 1er-Moves sortieren (weiter weg vom Gegner = besser)
        if one_step_moves:
            sorted_one_step, _ = self.score_safe_moves(
                one_step_moves, enemy_list
            )
            result_moves.extend(sorted_one_step)

        # 7) DANN: längere Moves sortieren und hinten anhängen
        if longer_moves:
            sorted_longer, _ = self.score_safe_moves(longer_moves, enemy_list)
            result_moves.extend(sorted_longer)

        # leere liste wenn es nichts ist
        if not result_moves:
            self.set_escape_list([])
            return []

        self.set_escape_list(result_moves)
        return result_moves


"""if __name__ == "__main__":
    # Beispiel: Test-Environment (7×7 = 49 Zeichen)
    # Hier kannst du beliebige Felder einfügen.
    # . = leer, * = Futter, B wird automatisch gesetzt.
    # Beispiel entspricht deinem Video / Zeichnung sehr ähnlich:
    env_string = "....*.....*............*..............*.........."

    beast = Beast()
    beast.set_environment(env_string)

    field = beast.parse_environment(env_string)
    for row in field:
        print(" ".join(row))

    print("\nFood gefunden an:", beast.locate_food_list())

    print("\nStarte chase_food() ...")
    moves = beast.chase_food()

    print("\nErgebnis der erweiterten Futter-Suche (Sortiert):")
    for i, m in enumerate(moves, 1):
        print(f"  {i}. Move = {m}")

    print("\nBest move (TOP 1):", moves[0])"""
