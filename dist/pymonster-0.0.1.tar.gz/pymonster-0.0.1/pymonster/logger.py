import os
from datetime import datetime
import json
import gzip
import shutil  # für "alte Datei in Ordner schieben"

game_round = 0

LOG_FOLDER = "logs"
ARCHIVE_FOLDER = os.path.join(LOG_FOLDER, "archive")
CHUNK_SIZE = 35000  # nach 35k Runden neue Datei


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def get_beast_log_file(bid, abs_r):
    """
    Bestimmt die .gz-Datei für dieses Beast und diese Runde.
    Alle CHUNK_SIZE Runden wird automatisch ein neuer Chunk benutzt.
    """
    ensure_dir(LOG_FOLDER)

    chunk_index = abs_r // CHUNK_SIZE  # 0,1,2,...
    filename = f"beast-{bid}_c{chunk_index:04d}.ndjson.gz"
    file_path = os.path.join(LOG_FOLDER, filename)
    return file_path, chunk_index


def archive_previous_chunk_if_exists(bid, chunk_index):
    """
    Wenn es einen vorherigen Chunk gibt (c0000, c0001, ...) und die Datei noch im Haupt-Ordner liegt,
    wird sie in ARCHIVE_FOLDER verschoben.
    """
    if chunk_index <= 0:
        return  # kein vorheriger Chunk

    prev_filename = f"beast-{bid}_c{chunk_index - 1:04d}.ndjson.gz"
    prev_path = os.path.join(LOG_FOLDER, prev_filename)

    if os.path.exists(prev_path):
        ensure_dir(ARCHIVE_FOLDER)
        target_path = os.path.join(ARCHIVE_FOLDER, prev_filename)
        # nur verschieben, wenn sie nicht schon im Archiv liegt
        if not os.path.exists(target_path):
            shutil.move(prev_path, target_path)


def log_server(servermsg: str, exceptions: str, searchstring="server"):
    """
    Server-Logs können auch in .gz, hier aber ohne Chunks.
    """
    ensure_dir(LOG_FOLDER)

    # Eine Datei pro Tag z.B.:
    timestamp = datetime.now().strftime("%Y%m%d")
    filename = f"{searchstring}_{timestamp}.ndjson.gz"
    file_path = os.path.join(LOG_FOLDER, filename)

    eintrag = {
        "r": game_round,
        "smsg": servermsg,
        "ex": exceptions,
    }

    line = (json.dumps(eintrag, ensure_ascii=False) + "\n").encode("utf-8")
    with gzip.open(file_path, "ab", compresslevel=1) as f:
        f.write(line)


def log_beast(**fields):
    """
    Beast-Log: direkt gzip, mit Chunking alle CHUNK_SIZE Runden
    und automatischem Archivieren des vorherigen Chunks.
    """
    global game_round
    game_round = fields.get("abs_r", 0)
    bid = fields.get("bid", "unknown")
    abs_r = fields.get("abs_r", 0)

    # richtige Datei für diese Runde bestimmen
    file_path, chunk_index = get_beast_log_file(bid, abs_r)

    # vorherigen Chunk (falls vorhanden) ins Archiv verschieben
    archive_previous_chunk_if_exists(bid, chunk_index)

    # Eintrag schreiben
    line = (json.dumps(fields, ensure_ascii=False) + "\n").encode("utf-8")
    with gzip.open(file_path, "ab", compresslevel=1) as f:
        f.write(line)
