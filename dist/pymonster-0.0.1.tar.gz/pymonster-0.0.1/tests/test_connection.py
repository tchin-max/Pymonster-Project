"""Tests for module module_3"""
