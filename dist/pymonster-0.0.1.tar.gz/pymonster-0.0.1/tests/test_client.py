"""Tests for module module_1"""
