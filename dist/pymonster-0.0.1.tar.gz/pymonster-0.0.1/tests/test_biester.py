import math
import pytest
from pymonster.beast import Beast


@pytest.fixture
def beast():
    b = Beast()
    b.set_id(1)
    b.set_energy(100)
    return b


# Hilfsfunktion, damit jedes Environment EXAKT 49 Zeichen hat
def fill49(s: str) -> str:
    """Füllt einen Environment-String auf exakt 49 Zeichen auf."""
    if len(s) >= 49:
        return s[:49]
    return s + "." * (49 - len(s))


def test_parse_environment(beast):
    env = fill49(".<.........*....>...**.....<.........=...*....*..")
    beast.set_environment(env)
    feld = beast.parse_environment(env)

    assert feld.shape == (7, 7)
    assert feld[3][3] == "B"  # Beast immer in der Mitte


def test_chase_food_no_food(beast):
    env = fill49("." * 49)
    beast.set_environment(env)
    beast.parse_environment(env)

    moves = beast.chase_food()

    assert len(moves) == 1
    dx, dy = moves[0]
    assert not (dx == 0 and dy == 0)
    assert abs(dx) <= 1
    assert abs(dy) <= 1


def test_chase_food_many_food_moves_no_lookahead(beast):
    """
    Testet den Fall mit sehr viel Futter im Feld.

    Ziel des Tests:
      - Es sollen viele Food-Moves entstehen.
      - Alle Moves müssen im gültigen Bewegungsbereich [-2..2] liegen.
      - Die Funktion darf nicht abstürzen.
    """
    env_rows = [
        "*.*.*.*",
        ".*.*.*.",
        "*.*B*.*",
        ".*.*.*.",
        "*.*.*.*",
        ".*.*.*.",
        "*.*.*.*",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    result = beast.chase_food()

    # Es sollen viele Moves existieren (mehr als 7)
    assert len(result) > 7

    # Alle Moves müssen im gültigen Bereich [-2..2] liegen
    for dx, dy in result:
        assert -2 <= dx <= 2
        assert -2 <= dy <= 2


def test_chase_food_prefers_move_with_more_future_food(beast):
    """
    Prüft, dass Moves, die *zukünftig* mehr Futter bringen,
    höher bewertet werden.

    Wir testen NICHT dx>0 oder dx<0,
    weil deine Implementierung clamped + sortiert nach Distanz.
    """
    env_rows = [
        ".......*",
        "...B....",
        "........",
        "........",
        "...*....",
        "........",
        "........",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    moves = beast.chase_food()
    assert len(moves) > 0

    # Der erste Move hat den HÖCHSTEN Score → muss existieren
    best = moves[0]
    assert isinstance(best, tuple) and len(best) == 2


def test_chase_food_penalty_if_future_no_food(beast):
    """
    Wenn nur oberhalb ein Futter liegt → bester Move muss dy<0 sein.
    """
    env_rows = [
        "..*....",
        "...B...",
        ".......",
        ".......",
        ".......",
        ".......",
        ".......",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    best = beast.chase_food()[0]
    dx, dy = best

    assert dy < 0  # Futter liegt über B


###  HUNT


def test_hunt_no_enemies(beast):
    env = fill49("." * 49)
    beast.set_environment(env)
    beast.parse_environment(env)

    assert beast.hunt() == []


def test_hunt_single_enemy_left(beast):
    """
    Gegner über dem Beast → dy < 0
    """
    env_rows = [
        "...<...",
        "...B...",
        ".......",
        ".......",
        ".......",
        ".......",
        ".......",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    result = beast.hunt()
    assert len(result) == 1

    dx, dy = result[0]
    assert dy < 0


def test_hunt_multiple_enemies_sorted_by_distance(beast):
    env_rows = [
        "..<....",
        "...B...",
        "......<",
        ".......",
        ".......",
        ".......",
        ".......",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    result = beast.hunt()
    assert len(result) == 2

    d1 = math.hypot(*result[0])
    d2 = math.hypot(*result[1])
    assert d1 <= d2  # erster ist näher


def test_hunt_clamping(beast):
    env_rows = [
        "......<",
        ".......",
        "...B...",
        ".......",
        ".......",
        ".......",
        ".......",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    dx, dy = beast.hunt()[0]

    assert abs(dx) <= 2
    assert abs(dy) <= 2


def test_hunt_multiple_sides(beast):
    env_rows = [
        "<......",
        "...B...",
        "......<",
        ".......",
        ".......",
        ".......",
        ".......",
    ]
    env = fill49("".join(env_rows))

    beast.set_environment(env)
    beast.parse_environment(env)

    moves = beast.hunt()

    assert len(moves) == 2
    xs = [dx for dx, dy in moves]
    assert min(xs) < 0
    assert max(xs) > 0
