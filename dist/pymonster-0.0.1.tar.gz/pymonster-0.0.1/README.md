<h1> Struktur/Architektur </h1>

![Transport](https://i.ibb.co/3YM22M4W/struktur.jpg)

![Klassendiagramm](https://i.ibb.co/BKyHTn4D/image.png)

![3-Stufen Strategie](https://i.ibb.co/BWwNtyn/3-Stufen-Strategie.jpg)

![Gehirn und Module](https://i.ibb.co/cStS9LzF/image.png)